/*Listagem dos filmes e séries assistidos por cada perfil*/
 SELECT 
    p.apelido AS perfil,
    tf.descricao AS titulo,
    'Filme' AS tipo,
    c.pais,
    c.estado,
    c.cidade
FROM perfil p
JOIN usuario u ON p.usuario_id = u.id
JOIN cadastro c ON c.usuario_id = u.id
JOIN reproducao_filme rf ON rf.perfil_id = p.id
JOIN titulo_filme tf ON tf.id = rf.titulo_filme_id 


UNION

SELECT 
    p.apelido AS perfil,
    ts.descricao AS titulo,
    'Série' AS tipo,
    c.pais,
    c.estado,
    c.cidade
FROM perfil p
JOIN usuario u ON p.usuario_id = u.id
JOIN cadastro c ON c.usuario_id = u.id
JOIN reproducao_serie rs ON rs.perfil_id = p.id
JOIN titulo_serie ts ON ts.id = rs.titulo_serie_id
ORDER BY perfil;

/*Média de avaliação de cada conteúdo*/

SELECT  nome AS filme, AVG (nota)     
FROM avaliacao_filme af 
JOIN titulo_filme tf ON af.titulo_filme_id = tf.id
JOIN filme f ON tf.filme_id = f.id
GROUP BY tf.id

UNION

SELECT nome AS serie, AVG(nota)
FROM avaliacao_serie av
JOIN titulo_serie ts ON av.titulo_serie_id = ts.id
JOIN serie s ON ts.serie_id = s.id
GROUP BY ts.id;

/*Listar os usuários inadimplentes*/

SELECT nome AS usuario_nome, pais, cidade, status
FROM pagamento p
JOIN usuario u ON p.usuario_id = u.id
JOIN cadastro c ON c.usuario_id = u.id 
WHERE status NOT IN(
SELECT status 
FROM pagamento
WHERE status = 'aprovado'
);

/*Listar conteúdos mais assistidos por usuários de um determinado país*/

SELECT pais,serie, vezes_assistidas
FROM (
  SELECT c.pais, s.nome AS serie, COUNT(s.nome) AS vezes_assistidas
  FROM perfil p
  JOIN usuario u ON p.usuario_id = u.id
  JOIN cadastro c ON c.usuario_id = u.id
  JOIN reproducao_serie rs ON rs.perfil_id = p.id
  JOIN titulo_serie ts ON rs.titulo_serie_id = ts.id
  JOIN serie s ON s.id = ts.serie_id
  GROUP BY c.pais, s.nome
) AS sub


UNION
  
  SELECT pais,filme, vezes_assistidas
  FROM (
  SELECT c.pais,f.nome AS filme, COUNT(f.nome) AS vezes_assistidas
  FROM perfil p
  JOIN usuario u ON p.usuario_id = u.id
  JOIN cadastro c ON c.usuario_id = u.id
  JOIN reproducao_filme rf ON rf.perfil_id = p.id
  JOIN titulo_filme tf ON rf.titulo_filme_id = tf.id
  JOIN filme f ON f.id = tf.filme_id
  GROUP BY c.pais, f.nome
  ) AS sub
ORDER BY vezes_assistidas DESC;  

/*Lista os perfis que não assistiram nada*/
SELECT p.*
FROM perfil p
JOIN usuario u ON p.usuario_id = u.id
JOIN cadastro c ON u.id = c.usuario_id
WHERE p.id NOT IN (
    SELECT perfil_id FROM reproducao_filme
    UNION
    SELECT perfil_id FROM reproducao_serie
);


/* prof, como eu disse na aula meu select ta meio bugado, então nao deu pra testar direito a última subquery que eu fiz em casa, maso resto eu fiz no senac e tava dando certo, mas é isso */





