CREATE DATABASE SENACSTREAM; 
USE SENACSTREAM;

/* Criação de tabelas*/
CREATE TABLE usuario (
id INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(110),
email VARCHAR(100) UNIQUE,
data_nascimento DATE,
online_agora TINYINT,
senha VARCHAR(256)
);

CREATE TABLE perfil (
id INT PRIMARY KEY AUTO_INCREMENT,
apelido VARCHAR(60),
maior_de_idade tinyint,
genero_favorito VARCHAR(45),
usuario_id INT,
FOREIGN KEY (usuario_id) REFERENCES usuario (id)
);

CREATE TABLE plano (
id INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(25),
preco_mensal DECIMAL(5,2) ,
quantidade_de_perfis INT,
qualidade VARCHAR(10)
);

CREATE TABLE filme (
id INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(100),
genero VARCHAR(80),
atores VARCHAR(250),
produtora VARCHAR(100)
);

CREATE TABLE serie (
id INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(100),
genero VARCHAR(80),
atores VARCHAR(250),
produtora VARCHAR(100)
);

CREATE TABLE cadastro (
id INT PRIMARY KEY AUTO_INCREMENT,
data_cadastro DATETIME,
pais VARCHAR(45),
estado VARCHAR(45),
cidade VARCHAR(45),
usuario_id INT,
FOREIGN KEY (usuario_id) REFERENCES usuario (id),
plano_id INT,
FOREIGN KEY (plano_id) REFERENCES plano (id)

);

CREATE TABLE titulo_filme (
id INT PRIMARY KEY AUTO_INCREMENT,
descricao VARCHAR(300),
classificacao_indicativa INT,
duracao_segundos INT,
ranking INT,
filme_id INT,
FOREIGN KEY (filme_id) REFERENCES filme (id)
);

CREATE TABLE titulo_serie (
id INT PRIMARY KEY AUTO_INCREMENT,
descricao VARCHAR(300),
classificacao_indicativa INT,
ranking INT,
temporadas INT,
episodios INT,
serie_id INT,
FOREIGN KEY (serie_id) REFERENCES serie (id)
);


CREATE TABLE reproducao_filme (
id INT PRIMARY KEY AUTO_INCREMENT,
data_inicio DATETIME,
duracao_assistida_segundos INT,
status VARCHAR(40),
perfil_id INT,
FOREIGN KEY (perfil_id) REFERENCES perfil (id),
titulo_filme_id INT,
FOREIGN KEY (titulo_filme_id) REFERENCES titulo_filme (id)

);

CREATE TABLE reproducao_serie (
id INT PRIMARY KEY AUTO_INCREMENT,
data_inicio DATETIME,
duracao_assistida_segundos INT,
status VARCHAR(40),
perfil_id INT,
FOREIGN KEY (perfil_id) REFERENCES perfil (id),
titulo_serie_id INT,
FOREIGN KEY (titulo_serie_id) REFERENCES titulo_serie (id)
);

CREATE TABLE avaliacao_filme (
id INT PRIMARY KEY AUTO_INCREMENT,
nota INT,
comentario VARCHAR(1000),
data_avaliacao DATE,
perfil_id INT,
FOREIGN KEY (perfil_id) REFERENCES perfil (id),
titulo_filme_id INT,
FOREIGN KEY (titulo_filme_id) REFERENCES titulo_filme (id)
);

CREATE TABLE avaliacao_serie (
id INT PRIMARY KEY AUTO_INCREMENT,
nota INT,
comentario VARCHAR(1000),
data_avaliacao DATE,
perfil_id INT,
FOREIGN KEY (perfil_id) REFERENCES perfil (id),
titulo_serie_id INT,
FOREIGN KEY (titulo_serie_id) REFERENCES titulo_serie (id)
);

CREATE TABLE pagamento (
id INT PRIMARY KEY AUTO_INCREMENT,
data_pagamento DATETIME,
valor DECIMAL(5,2),
status VARCHAR(20),
observacao VARCHAR(255),
usuario_id INT,
FOREIGN KEY (usuario_id) REFERENCES usuario(id)

);
/* criação dos índices*/
CREATE INDEX idx_pagamento ON pagamento (status); /* Para consultar mais rápido se o cliente fez o pagamento, economizando tempo e memória*/
CREATE INDEX idx_email ON usuario(email); /*Para consultar o email do usuário para verificação da senha da sua conta de forma mais rápida e prática*/
CREATE INDEX idx_genero_favorito ON perfil(genero_favorito); /*Para consultar o genero favorito da conta, sugerindo filmes e séries mais rapidamente conforme o genêro selecionado pelo perfil*/



/* Função que representa a média de cada conteúdo:*/
DELIMITER $$

CREATE FUNCTION MediaAvaliacaoFilme(filme_id_input INT)
RETURNS DECIMAL(5,2)
DETERMINISTIC
BEGIN
    DECLARE media DECIMAL(5,2);

    SELECT IFNULL(AVG(nota), 0)
    INTO media
    FROM avaliacao_filme
    WHERE titulo_filme_id = filme_id_input;

    RETURN media;
END$$

DELIMITER ;

/* Procedure que representa o relatório de usuários ativos e suas informações*/
DELIMITER $$

CREATE PROCEDURE RelatorioUsuariosAtivos()
BEGIN
    SELECT 
        u.nome AS nome_usuario,
        u.email,
        p.nome AS plano_assinatura,
        c.pais,
        c.estado,
        c.cidade
    FROM usuario u
    JOIN cadastro c ON u.id = c.usuario_id
    JOIN plano p ON c.plano_id = p.id
    WHERE u.online_agora = 1;
END$$

DELIMITER ;


/*Trigger que representa a atualização de pagamento na observação toda vez que for indicado como aprovado*/
DELIMITER $$

CREATE TRIGGER atualiza_pagamento_aprovado
BEFORE INSERT ON pagamento
FOR EACH ROW
BEGIN
    IF NEW.status = 'aprovado' THEN
        SET NEW.observacao = 'Pagamento aprovado automaticamente';
    END IF;
END$$

DELIMITER ;


/*Cria um trigger que atualiza a observação do pagamento para confirmar a aprovação sempre que uma data nova é inserida e  o seu status for 'aprovado' */

DELIMITER //

CREATE TRIGGER trigger_pagamento_aprovado
BEFORE UPDATE ON pagamento
FOR EACH ROW
BEGIN
    -- Verifica se a data foi modificada e o novo status é 'Aprovado'
    IF NEW.data_pagamento IS NOT NULL AND OLD.data_pagamento <> NEW.data_pagamento
       AND LOWER(NEW.status) = 'aprovado' THEN
        SET NEW.observacao = 'Pagamento realmente aprovado';
    END IF;
END;
//

DELIMITER ;



/*inserção dos dados*/
INSERT INTO plano (id,nome, preco_mensal, quantidade_de_perfis, qualidade) VALUES
(1,'Básico', 20.00, 1, 'SD'),
(2,'Padrão', 35.00, 3, 'HD'),
(3,'Premium', 50.00, 5, '4K');

/*Inserção do usuário com senha*/
INSERT INTO usuario (id, nome, email, data_nascimento, online_agora, senha) VALUES
(1, 'Ana Souza', 'ana1@email.com', '1990-05-10', 1, SHA2('senha123', 256)),
(2, 'Carlos Lima', 'carlos2@email.com', '1985-03-22', 0, SHA2('usuario2025', 256)),
(3, 'Beatriz Costa', 'beatriz3@email.com', '1992-07-15', 0, SHA2('admin2023', 256)),
(4, 'Marcos Silva', 'marcos4@email.com', '1999-12-01', 1, SHA2('abc123', 256)),
(5, 'Julia Fernandes', 'julia5@email.com', '2001-11-19', 1, SHA2('qwerty', 256)),
(6, 'Lucas Almeida', 'lucas6@email.com', '1988-08-08', 0, SHA2('123456', 256)),
(7, 'Fernanda Rocha', 'fernanda7@email.com', '1994-04-18', 1, SHA2('password', 256)),
(8, 'Paulo Mendes', 'paulo8@email.com', '1980-01-01', 1, SHA2('letmein', 256)),
(9, 'Roberta Dias', 'roberta9@email.com', '2000-06-30', 0, SHA2('welcome', 256)),
(10, 'Thiago Ramos', 'thiago10@email.com', '1995-10-23', 1, SHA2('monkey', 256)),
(11, 'Lívia Castro', 'livia11@email.com', '1993-09-09', 0, SHA2('dragon', 256)),
(12, 'Henrique Moraes', 'henrique12@email.com', '1987-07-13', 1, SHA2('football', 256)),
(13, 'Amanda Torres', 'amanda13@email.com', '1996-02-17', 1, SHA2('baseball', 256)),
(14, 'Gabriel Nunes', 'gabriel14@email.com', '1991-05-05', 0, SHA2('iloveyou', 256)),
(15, 'Camila Barros', 'camila15@email.com', '2002-03-03', 1, SHA2('sunshine', 256)),
(16, 'Ricardo Antunes', 'ricardo16@email.com', '1998-06-06', 1, SHA2('princess', 256)),
(17, 'Patrícia Teixeira', 'patricia17@email.com', '1997-01-12', 0, SHA2('admin123', 256)),
(18, 'João Vitor', 'joao18@email.com', '1990-09-21', 0, SHA2('master', 256)),
(19, 'Daniele Martins', 'daniele19@email.com', '1989-10-10', 1, SHA2('hello123', 256)),
(20, 'Felipe Rocha', 'felipe20@email.com', '1995-12-24', 1, SHA2('freedom', 256)),
(21, 'Larissa Gomes', 'larissa21@email.com', '1993-11-11', 0, SHA2('whatever', 256)),
(22, 'Eduardo Batista', 'eduardo22@email.com', '2000-02-02', 1, SHA2('qazwsx', 256)),
(23, 'Vanessa Lopes', 'vanessa23@email.com', '1999-04-04', 1, SHA2('trustno1', 256)),
(24, 'Pedro Henrique', 'pedro24@email.com', '1991-01-15', 0, SHA2('123qwe', 256)),
(25, 'Isabela Rezende', 'isabela25@email.com', '1994-08-29', 1, SHA2('password1', 256));
/*inserção do cadastro com as informações de plano e localidade*/
INSERT INTO cadastro (id,data_cadastro, pais, estado, cidade, usuario_id, plano_id) VALUES
(1,'2023-01-10 12:00:00', 'Brasil', 'SP', 'São Paulo', 1, 1),
(2,'2023-01-11 13:10:00', 'Brasil', 'RJ', 'Rio de Janeiro', 2, 2),
(3,'2023-01-12 09:20:00', 'Argentina', 'Buenos Aires', 'Buenos Aires', 3, 3),
(4,'2023-01-13 14:00:00', 'Brasil', 'MG', 'Belo Horizonte', 4, 1),
(5,'2023-01-14 10:00:00', 'Brasil', 'RS', 'Porto Alegre', 5, 2),
(6,'2023-01-15 16:00:00', 'México', 'CDMX', 'Cidade do México', 6, 3),
(7,'2023-01-16 11:30:00', 'Brasil', 'BA', 'Salvador', 7, 1),
(8,'2023-01-17 17:40:00', 'Brasil', 'PR', 'Curitiba', 8, 2),
(9,'2023-01-18 18:00:00', 'Portugal', 'Lisboa', 'Lisboa', 9, 3),
(10,'2023-01-19 15:25:00', 'Brasil', 'SC', 'Florianópolis', 10, 1),
(11,'2023-01-20 13:30:00', 'Chile', 'RM', 'Santiago', 11, 2),
(12,'2023-01-21 19:10:00', 'Brasil', 'PE', 'Recife', 12, 3),
(13,'2023-01-22 20:00:00', 'Brasil', 'CE', 'Fortaleza', 13, 1),
(14,'2023-01-23 21:15:00', 'Brasil', 'GO', 'Goiânia', 14, 2),
(15,'2023-01-24 22:10:00', 'Brasil', 'DF', 'Brasília', 15, 3),
(16,'2023-01-25 23:00:00', 'Brasil', 'PB', 'João Pessoa', 16, 1),
(17,'2023-01-26 08:00:00', 'Brasil', 'AL', 'Maceió', 17, 2),
(18,'2023-01-27 07:45:00', 'Brasil', 'RN', 'Natal', 18, 3),
(19,'2023-01-28 06:50:00', 'Brasil', 'AM', 'Manaus', 19, 1),
(20,'2023-01-29 05:30:00', 'Brasil', 'PA', 'Belém', 20, 2),
(21,'2023-01-30 04:40:00', 'EUA', 'CA', 'Los Angeles', 21, 3),
(22,'2023-01-31 03:35:00', 'EUA', 'NY', 'Nova York', 22, 1),
(23,'2023-02-01 02:20:00', 'Canadá', 'ON', 'Toronto', 23, 2),
(24,'2023-02-02 01:10:00', 'Inglaterra', 'London', 'Londres', 24, 3),
(25,'2023-02-03 00:00:00', 'Espanha', 'Madrid', 'Madrid', 25, 1);

/*Inserção dos perfis com os filtros de cada um para algoritmo do conteúdo apresentado*/
INSERT INTO perfil (id,apelido, maior_de_idade, genero_favorito, usuario_id) VALUES
(1,'Aninha', 1, 'Drama', 1),
(2,' Carlão', 1, 'Ação', 2),
(3,' Be', 1, 'Comédia', 3),
(4,' Marcolas', 1, 'Terror', 4),
(5,' Jujuba', 1, 'Romance', 5),
(6,' Arrocha', 1, 'Ficção', 6),
(7,' Felix', 1, 'Suspense', 7),
(8,' Paulinho', 1, 'Documentário', 8),
(9,' Diva', 1, 'Animação', 9),
(10,' Thiaguera', 1, 'Aventura', 10),
(11,' Líviiinha', 1, 'Drama', 11),
(12,' Rick', 1, 'Ação', 12),
(13,' Amandinha', 1, 'Romance', 13),
(14,' Biel', 1, 'Comédia', 14),
(15,' Ca', 1, 'Suspense', 15),
(16,' Pelotinha', 1, 'Drama', 16),
(17,' Pat', 1, 'Animação', 17),
(18,' Jhones', 1, 'Aventura', 18),
(19,' Daniele', 1, 'Ficção', 19),
(20,' F', 1, 'Terror', 20),
(21,' Lari', 1, 'Comédia', 21),
(22,' Dudu', 1, 'Romance', 22),
(23,' Vanessa', 1, 'Ação', 23),
(24,' Pedrinho M', 1, 'Documentário', 24),
(25,' Belaa', 1, 'Suspense', 25);

/* Inserção separada das informações do filme das informações das séries*/
INSERT INTO filme (id,nome, genero, atores, produtora) VALUES
(1,'O Poderoso Chefão', 'Crime, Drama', 'Marlon Brando, Al Pacino', 'Paramount Pictures'),
(2,'Titanic', 'Romance, Drama', 'Leonardo DiCaprio, Kate Winslet', '20th Century Fox'),
(3,'Gladiador', 'Ação, Drama', 'Russell Crowe, Joaquin Phoenix', 'DreamWorks'),
(4,'Forrest Gump', 'Drama, Romance', 'Tom Hanks, Robin Wright', 'Paramount Pictures'),
(5,'Matrix', 'Ficção Científica, Ação', 'Keanu Reeves, Laurence Fishburne', 'Warner Bros.'),
(6,'Interestelar', 'Ficção Científica, Drama', 'Matthew McConaughey, Anne Hathaway', 'Paramount Pictures'),
(7,'Clube da Luta', 'Drama', 'Brad Pitt, Edward Norton', '20th Century Fox'),
(8,'O Senhor dos Anéis: A Sociedade do Anel', 'Aventura, Fantasia', 'Elijah Wood, Ian McKellen', 'New Line Cinema'),
(9,'A Origem', 'Ação, Ficção Científica', 'Leonardo DiCaprio, Joseph Gordon-Levitt', 'Warner Bros.'),
(10,'Coringa', 'Drama, Crime', 'Joaquin Phoenix, Robert De Niro', 'Warner Bros.'),
(11,'Pantera Negra', 'Ação, Ficção Científica', 'Chadwick Boseman, Michael B. Jordan', 'Marvel Studios'),
(12,'Vingadores: Ultimato', 'Ação, Aventura', 'Robert Downey Jr., Chris Evans', 'Marvel Studios'),
(13,'Os Incríveis', 'Animação, Ação', 'Craig T. Nelson, Holly Hunter', 'Pixar Animation Studios'),
(14,'Toy Story', 'Animação, Aventura', 'Tom Hanks, Tim Allen', 'Pixar Animation Studios'),
(15,'O Rei Leão', 'Animação, Aventura', 'Matthew Broderick, James Earl Jones', 'Walt Disney Pictures');

INSERT INTO serie (id,nome, genero, atores, produtora) VALUES
(1,'Breaking Bad', 'Crime, Drama, Thriller', 'Bryan Cranston, Aaron Paul', 'AMC'),
(2,'Game of Thrones', 'Drama, Fantasia', 'Emilia Clarke, Kit Harington', 'HBO'),
(3,'Stranger Things', 'Ficção Científica, Terror', 'Millie Bobby Brown, David Harbour', 'Netflix'),
(4,'Friends', 'Comédia, Romance', 'Jennifer Aniston, Courteney Cox', 'NBC'),
(5,'The Office', 'Comédia', 'Steve Carell, John Krasinski', 'NBC'),
(6,'The Crown', 'Drama, Histórico', 'Olivia Colman, Helena Bonham Carter', 'Netflix'),
(7,'Dark', 'Ficção Científica, Mistério', 'Louis Hofmann, Karoline Eichhorn', 'Netflix'),
(8,'Narcos', 'Crime, Drama', 'Wagner Moura, Pedro Pascal', 'Netflix'),
(9,'Sherlock', 'Crime, Drama, Mistério', 'Benedict Cumberbatch, Martin Freeman', 'BBC'),
(10,'The Mandalorian', 'Ficção Científica, Ação', 'Pedro Pascal', 'Lucasfilm'),
(11,'House of the Dragon', 'Fantasia, Drama', 'Paddy Considine, Matt Smith', 'HBO'),
(12,'Wandinha', 'Comédia, Mistério', 'Jenna Ortega, Gwendoline Christie', 'Netflix'),
(13,'La Casa de Papel', 'Crime, Ação', 'Álvaro Morte, Úrsula Corberó', 'Netflix'),
(14,'The Last of Us', 'Drama, Ação', 'Pedro Pascal, Bella Ramsey', 'HBO'),
(15,'Better Call Saul', 'Crime, Drama', 'Bob Odenkirk, Rhea Seehorn', 'AMC');

/*Inserção separada dos filmes e das séries na apresentação deles ao usuário*/
INSERT INTO titulo_filme (id,descricao, classificacao_indicativa, duracao_segundos, ranking, filme_id) VALUES
(1,'Uma obra-prima sobre a máfia italiana.', 18, 10500, 1, 1),
(2,'Uma trágica história de amor no Titanic.', 14, 11700, 2, 2),
(3,'Um general romano busca vingança.', 16, 9300, 11, 3),
(4,'A vida é como uma caixa de chocolates.', 10, 8520, 4, 4),
(5,'O despertar para um mundo simulado.', 14, 8160, 3, 5),
(6,'Exploração interestelar para salvar a humanidade.', 12, 10140, 15, 6),
(7,'Dois homens formam um clube secreto.', 18, 8340, 5, 7),
(8,'Uma jornada épica pela Terra Média.', 12, 13020, 6, 8),
(9,'Roubo de sonhos e manipulação da mente.', 14, 8880, 9, 9),
(10,'A queda psicológica de um homem marginalizado.', 18, 7320, 10, 10),
(11,'Um rei guerreiro luta por Wakanda.', 12, 8040, 8, 11),
(12,'O confronto final dos Vingadores.', 12, 10860, 12, 12),
(13,'Família de super-heróis combate vilões.', 10, 6900, 13, 13),
(14,'Brinquedos ganham vida quando ninguém vê.', 0, 4860, 14, 14),
(15,'A jornada de um leão em busca de seu lugar.', 0, 5280, 7, 15);

INSERT INTO titulo_serie (id,descricao, classificacao_indicativa, ranking, temporadas, episodios, serie_id) VALUES
(1,'Um professor vira traficante para salvar sua família.', 18, 5, 5, 62, 1),
(2,'Famílias nobres disputam o Trono de Ferro.', 18, 2, 8, 73, 2),
(3,'Um grupo enfrenta forças sobrenaturais nos anos 80.', 14, 10, 4, 34, 3),
(4,'Seis amigos vivem aventuras em Nova York.', 12, 4, 10, 236, 4),
(5,'Funcionários de um escritório vivem situações hilárias.', 10, 8, 9, 201, 5),
(6,'A história da família real britânica.', 14, 13, 6, 60, 6),
(7,'Viagem no tempo e segredos familiares na Alemanha.', 16, 7, 3, 26, 7),
(8,'A ascensão e queda de Pablo Escobar.', 18, 3, 3, 30, 8),
(9,'Um detetive genial resolve crimes complexos.', 12, 9, 4, 13, 9),
(10,'Um caçador de recompensas em uma galáxia distante.', 12, 15, 3, 24, 10),
(11,'Os ancestrais de Westeros lutam pelo poder.', 18, 11, 1, 10, 11),
(12,'A filha da Família Addams em um internato.', 12, 12, 1, 8, 12),
(13,'Ladrões tentam executar o maior roubo da história.', 16, 1, 5, 41, 13),
(14,'Dois sobreviventes enfrentam um mundo pós-apocalíptico.', 18, 14, 1, 9, 14),
(15,'A origem do advogado Saul Goodman.', 16, 6, 6, 63, 15);

/*Inserção das avaliações dos filmes e séries feito pelos perfis separados também*/
INSERT INTO avaliacao_filme (id,nota, comentario, data_avaliacao, perfil_id, titulo_filme_id) VALUES
(1,5, 'Filme incrível, roteiro impecável!', '2025-06-01', 1, 1),
(2,4, 'Atuações excelentes, vale a pena ver.', '2025-06-01', 1, 2),
(3,5, 'Muito emocionante do início ao fim.', '2025-06-01', 2, 3),
(4,3, 'Esperava mais do desfecho.', '2025-06-01', 2, 4),
(5,4, 'Fotografia sensacional.', '2025-06-01', 3, 5),
(6,5, 'Clássico que nunca envelhece.', '2025-06-01', 3, 6),
(7,2, 'História confusa, mas bem filmado.', '2025-06-01', 4, 7),
(8,4, 'Muito criativo, gostei bastante.', '2025-06-01', 4, 8),
(9,5, 'Épico! Tudo é grandioso.', '2025-06-01', 5, 9),
(10,4, 'Um pouco longo, mas excelente.', '2025-06-01', 5, 10),
(11,3, 'Bom, mas não é meu estilo.', '2025-06-01', 6, 11),
(12,5, 'Filme de super-herói top!', '2025-06-01', 6, 12),
(13,4, 'Muito divertido para a família.', '2025-06-01', 7, 13),
(14,5, 'Ótima animação, bem produzida.', '2025-06-01', 7, 14),
(15,5, 'Obra de arte da Disney.', '2025-06-01', 8, 15),
(16,4, 'Nostálgico e envolvente.', '2025-06-01', 8, 1),
(17,5, 'História poderosa, merece prêmios.', '2025-06-01', 9, 2),
(18,3, 'Boa atuação, mas lento.', '2025-06-01', 9, 3),
(19,5, 'Muito emocionante!', '2025-06-01', 10, 4),
(20,4, 'Grande produção e bom ritmo.', '2025-06-01', 10, 5),
(21,5, 'Mind-blowing! Surpreendente.', '2025-06-01', 11, 6),
(22,4, 'Drama muito bem dirigido.', '2025-06-01', 11, 7),
(23,3, 'Final decepcionante.', '2025-06-01', 12, 8),
(24,5, 'Um dos melhores que já vi.', '2025-06-01', 12, 9),
(25,4, 'Muito bom para ver em família.', '2025-06-01', 13, 10),
(26,5, 'Inesquecível!', '2025-06-01', 13, 11),
(27,5, 'Roteiro inteligente e diferente.', '2025-06-01', 14, 12),
(28,4, 'Cheio de ação e bons efeitos.', '2025-06-01', 14, 13),
(29,3, 'Animação fraca, esperava mais.', '2025-06-01', 15, 14),
(30,4, 'Clássico da infância.', '2025-06-01', 15, 15),
(31,5, 'Muito bem feito e emocionante.', '2025-06-01', 16, 1),
(32,3, 'Bom elenco, roteiro mediano.', '2025-06-01', 16, 2),
(33,4, 'Impactante e forte.', '2025-06-01', 17, 3),
(34,5, 'Maravilhoso, recomendo.', '2025-06-01', 17, 4),
(35,5, 'Top 5 filmes da minha vida.', '2025-06-01', 18, 5),
(36,4, 'Muito criativo!', '2025-06-01', 18, 6),
(37,2, 'Deixou a desejar.', '2025-06-01', 19, 7),
(38,5, 'Tudo perfeito.', '2025-06-01', 19, 8),
(39,3, 'Achei chato.', '2025-06-01', 20, 9),
(40,5, 'Filme excelente.', '2025-06-01', 20, 10),
(41,4, 'Gostei bastante.', '2025-06-01', 21, 11),
(42,5, 'Maravilhoso visualmente.', '2025-06-01', 21, 12),
(43,4, 'Bom para todas as idades.', '2025-06-01', 22, 13),
(44,5, 'Recomendo.', '2025-06-01', 22, 14),
(45,4, 'Linda história.', '2025-06-01', 23, 15),
(46,3, 'Ok, mas nada demais.', '2025-06-01', 23, 1),
(47,5, 'Roteiro genial.', '2025-06-01', 24, 2),
(48,4, 'Filme marcante.', '2025-06-01', 24, 3),
(49,5, 'Assistiria de novo.', '2025-06-01', 25, 4),
(50,3, 'Bom, mas já vi melhores.', '2025-06-01', 25, 5);

INSERT INTO avaliacao_serie (id,nota, comentario, data_avaliacao, perfil_id, titulo_serie_id) VALUES
(1,5, 'Série viciante, ótima atuação.', '2025-06-01', 1, 1),
(2,4, 'História muito bem escrita.', '2025-06-01', 1, 2),
(3,5, 'Final épico!', '2025-06-01', 2, 3),
(4,4, 'Visual impecável.', '2025-06-01', 2, 4),
(5,3, 'Boa, mas cansativa em alguns episódios.', '2025-06-01', 3, 5),
(6,5, 'Muito realista e envolvente.', '2025-06-01', 3, 6),
(7,5, 'Ficção científica de respeito.', '2025-06-01', 4, 7),
(8,4, 'Adorei o elenco.', '2025-06-01', 4, 8),
(9,5, 'Incrível desde o piloto.', '2025-06-01', 5, 9),
(10,3, 'Alguns episódios são chatos.', '2025-06-01', 5, 10),
(11,5, 'Adorei cada detalhe.', '2025-06-01', 6, 11),
(12,4, 'Boa trama, personagens cativantes.', '2025-06-01', 6, 12),
(13,3, 'Muito sangrenta, mas bem feita.', '2025-06-01', 7, 13),
(14,5, 'Espetacular!', '2025-06-01', 7, 14),
(15,5, 'Amo essa série!', '2025-06-01', 8, 15),
(16,4, 'Assisti tudo em 2 dias.', '2025-06-01', 8, 1),
(17,5, 'Melhor que muita série por aí.', '2025-06-01', 9, 2),
(18,3, 'Começa bem, depois cansa.', '2025-06-01', 9, 3),
(19,4, 'História bem contada.', '2025-06-01', 10, 4),
(20,5, 'Personagens carismáticos.', '2025-06-01', 10, 5),
(21,4, 'Gostei do suspense.', '2025-06-01', 11, 6),
(22,5, 'Me prendeu desde o início.', '2025-06-01', 11, 7),
(23,3, 'Confusa, mas interessante.', '2025-06-01', 12, 8),
(24,4, 'Boa produção.', '2025-06-01', 12, 9),
(25,5, 'Fenomenal!', '2025-06-01', 13, 10),
(26,4, 'Belos efeitos.', '2025-06-01', 13, 11),
(27,5, 'Personagens cativantes.', '2025-06-01', 14, 12),
(28,3, 'Previsível.', '2025-06-01', 14, 13),
(29,4, 'Boa trama.', '2025-06-01', 15, 14),
(30,5, 'Roteiro incrível.', '2025-06-01', 15, 15),
(31,5, 'Valeu cada minuto.', '2025-06-01', 16, 1),
(32,4, 'Muito bem atuada.', '2025-06-01', 16, 2),
(33,3, 'Demora para engrenar.', '2025-06-01', 17, 3),
(34,5, 'História fantástica.', '2025-06-01', 17, 4),
(35,5, 'Muito realista.', '2025-06-01', 18, 5),
(36,4, 'Gostei bastante.', '2025-06-01', 18, 6),
(37,5, 'Assistiria novamente.', '2025-06-01', 19, 7),
(38,4, 'Personagens bem construídos.', '2025-06-01', 19, 8),
(39,3, 'Nada de novo.', '2025-06-01', 20, 9),
(40,5, 'Excelente roteiro.', '2025-06-01', 20, 10),
(41,4, 'Bem dirigida.', '2025-06-01', 21, 11),
(42,5, 'Muito interessante.', '2025-06-01', 21, 12),
(43,4, 'Ótima série.', '2025-06-01', 22, 13),
(44,5, 'A melhor do ano!', '2025-06-01', 22, 14),
(45,3, 'Legal, mas enrolada.', '2025-06-01', 23, 15),
(46,4, 'Divertida.', '2025-06-01', 23, 1),
(47,5, 'Sensacional.', '2025-06-01', 24, 2),
(48,4, 'Muito criativa.', '2025-06-01', 24, 3),
(49,5, 'Sem defeitos.', '2025-06-01', 25, 4),
(50,3, 'Mais ou menos.', '2025-06-01', 25, 5);
/* Inserção dos dados de visualização dos perfis de cada filme e série*/
INSERT INTO reproducao_filme (id,data_inicio, duracao_assistida_segundos, status, perfil_id, titulo_filme_id) VALUES
(1,'2025-06-01 20:15:00', 6800, 'finalizado', 1, 1),
(2,'2025-06-02 18:30:00', 3500, 'em andamento', 1, 2),
(3,'2025-06-01 21:00:00', 7400, 'finalizado', 2, 3),
(4,'2025-06-03 19:45:00', 4000, 'interrompido', 2, 4),
(5,'2025-06-01 22:00:00', 6500, 'finalizado', 3, 5),
(6,'2025-06-04 17:30:00', 2200, 'em andamento', 3, 6),
(7,'2025-06-02 20:00:00', 3600, 'em andamento', 4, 7),
(8,'2025-06-05 16:00:00', 7200, 'finalizado', 4, 8),
(9,'2025-06-01 20:45:00', 8000, 'finalizado', 5, 9),
(10,'2025-06-06 15:00:00', 6000, 'finalizado', 5, 10),
(11,'2025-06-02 18:00:00', 3100, 'em andamento', 6, 11),
(12,'2025-06-03 20:00:00', 7200, 'finalizado', 6, 12),
(13,'2025-06-01 19:00:00', 6500, 'finalizado', 7, 13),
(14,'2025-06-04 21:00:00', 2800, 'interrompido', 7, 14),
(15,'2025-06-02 22:30:00', 7200, 'finalizado', 8, 15),
(16,'2025-06-06 19:00:00', 4500, 'em andamento', 8, 1),
(17,'2025-06-01 21:30:00', 5200, 'interrompido', 9, 2),
(18,'2025-06-04 20:00:00', 6800, 'finalizado', 9, 3),
(19,'2025-06-02 20:00:00', 5900, 'finalizado', 10, 4),
(20,'2025-06-05 17:00:00', 3200, 'em andamento', 10, 5),
(21,'2025-06-01 23:00:00', 7100, 'finalizado', 11, 6),
(22,'2025-06-03 19:30:00', 3400, 'interrompido', 11, 7),
(23,'2025-06-02 21:00:00', 7200, 'finalizado', 12, 8),
(24,'2025-06-06 18:00:00', 3600, 'em andamento', 12, 9),
(25,'2025-06-01 19:45:00', 7400, 'finalizado', 13, 10),
(26,'2025-06-04 22:00:00', 3800, 'interrompido', 13, 11),
(27,'2025-06-02 19:00:00', 7200, 'finalizado', 14, 12),
(28,'2025-06-05 21:00:00', 3400, 'em andamento', 14, 13),
(29,'2025-06-01 20:00:00', 6900, 'finalizado', 15, 14),
(30,'2025-06-03 18:30:00', 2500, 'interrompido', 15, 15),
(31,'2025-06-02 22:00:00', 7200, 'finalizado', 16, 1),
(32,'2025-06-06 20:00:00', 4600, 'em andamento', 16, 2),
(33,'2025-06-01 21:15:00', 6800, 'finalizado', 17, 3),
(34,'2025-06-04 23:00:00', 3900, 'em andamento', 17, 4),
(35,'2025-06-02 18:45:00', 7300, 'finalizado', 18, 5),
(36,'2025-06-05 19:15:00', 2700, 'interrompido', 18, 6),
(37,'2025-06-01 22:30:00', 6400, 'finalizado', 19, 7),
(38,'2025-06-03 17:30:00', 3300, 'em andamento', 19, 8),
(39,'2025-06-02 20:30:00', 7100, 'finalizado', 20, 9),
(40,'2025-06-06 17:45:00', 3800, 'interrompido', 20, 10),
(41,'2025-06-01 19:30:00', 7000, 'finalizado', 21, 11),
(42,'2025-06-04 20:15:00', 2600, 'interrompido', 21, 12),
(43,'2025-06-02 21:45:00', 7200, 'finalizado', 22, 13),
(44,'2025-06-05 22:00:00', 3500, 'em andamento', 22, 14),
(45,'2025-06-01 18:15:00', 7400, 'finalizado', 23, 15),
(46,'2025-06-03 20:30:00', 2900, 'em andamento', 23, 1),
(47,'2025-06-02 19:15:00', 6800, 'finalizado', 24, 2),
(48,'2025-06-06 16:30:00', 3100, 'interrompido', 24, 3),
(49,'2025-06-01 21:00:00', 7200, 'finalizado', 25, 4),
(50,'2025-06-05 18:30:00', 3600, 'em andamento', 25, 5);

INSERT INTO reproducao_serie (id,data_inicio, duracao_assistida_segundos, status, perfil_id, titulo_serie_id) VALUES
(1,'2025-06-01 19:30:00', 1600, 'em andamento', 1, 1),
(2,'2025-06-02 22:00:00', 3300, 'finalizado', 1, 2),
(3,'2025-06-01 20:45:00', 2400, 'finalizado', 2, 3),
(4,'2025-06-03 21:00:00', 1900, 'interrompido', 2, 4),
(5,'2025-06-01 19:15:00', 3100, 'finalizado', 3, 5),
(6,'2025-06-04 20:30:00', 1200, 'em andamento', 3, 6),
(7,'2025-06-02 21:30:00', 2300, 'finalizado', 4, 7),
(8,'2025-06-05 22:45:00', 900, 'interrompido', 4, 8),
(9,'2025-06-01 20:30:00', 2900, 'finalizado', 5, 9),
(10,'2025-06-06 23:00:00', 1700, 'em andamento', 5, 10),
(11,'2025-06-02 19:30:00', 2600, 'finalizado', 6, 11),
(12,'2025-06-03 22:15:00', 800, 'interrompido', 6, 12),
(13,'2025-06-01 18:45:00', 3100, 'finalizado', 7, 13),
(14,'2025-06-04 21:15:00', 1000, 'em andamento', 7, 14),
(15,'2025-06-02 20:15:00', 2800, 'finalizado', 8, 15),
(16,'2025-06-06 20:45:00', 1400, 'em andamento', 8, 1),
(17,'2025-06-01 22:00:00', 2300, 'finalizado', 9, 2),
(18,'2025-06-04 18:00:00', 700, 'interrompido', 9, 3),
(19,'2025-06-02 19:00:00', 2600, 'finalizado', 10, 4),
(20,'2025-06-05 19:45:00', 1300, 'em andamento', 10, 5),
(21,'2025-06-01 23:00:00', 2900, 'finalizado', 11, 6),
(22,'2025-06-03 19:00:00', 950, 'interrompido', 11, 7),
(23,'2025-06-02 21:30:00', 3100, 'finalizado', 12, 8),
(24,'2025-06-06 22:30:00', 1100, 'em andamento', 12, 9),
(25,'2025-06-01 18:30:00', 2500, 'finalizado', 13, 10),
(26,'2025-06-04 19:15:00', 1000, 'em andamento', 13, 11),
(27,'2025-06-02 20:30:00', 2800, 'finalizado', 14, 12),
(28,'2025-06-05 21:00:00', 750, 'interrompido', 14, 13),
(29,'2025-06-01 21:00:00', 3000, 'finalizado', 15, 14),
(30,'2025-06-03 20:15:00', 1500, 'em andamento', 15, 15),
(31,'2025-06-02 22:15:00', 2300, 'finalizado', 16, 1),
(32,'2025-06-06 18:30:00', 900, 'interrompido', 16, 2),
(33,'2025-06-01 20:00:00', 3100, 'finalizado', 17, 3),
(34,'2025-06-04 22:30:00', 1000, 'em andamento', 17, 4),
(35,'2025-06-02 19:15:00', 2500, 'finalizado', 18, 5),
(36,'2025-06-05 18:30:00', 1200, 'em andamento', 18, 6),
(37,'2025-06-01 19:00:00', 2600, 'finalizado', 19, 7),
(38,'2025-06-03 21:30:00', 950, 'interrompido', 19, 8),
(39,'2025-06-02 21:00:00', 2800, 'finalizado', 20, 9),
(40,'2025-06-06 19:00:00', 1300, 'em andamento', 20, 10),
(41,'2025-06-01 22:30:00', 2700, 'finalizado', 21, 11),
(42,'2025-06-04 20:30:00', 800, 'interrompido', 21, 12),
(43,'2025-06-02 20:45:00', 3000, 'finalizado', 22, 13),
(44,'2025-06-05 22:15:00', 1000, 'em andamento', 22, 14),
(45,'2025-06-01 21:30:00', 3100, 'finalizado', 23, 15),
(46,'2025-06-03 23:00:00', 950, 'em andamento', 23, 1),
(47,'2025-06-02 19:45:00', 2400, 'finalizado', 24, 2),
(48,'2025-06-06 20:15:00', 1200, 'interrompido', 24, 3),
(49,'2025-06-01 20:30:00', 2600, 'finalizado', 25, 4),
(50,'2025-06-05 19:15:00', 1100, 'em andamento', 25, 5);

/* Inserção dos recebimentos de pagamentos dos usuários para a empresa*/
INSERT INTO pagamento (id,data_pagamento, valor, status, usuario_id) VALUES
(1,'2025-05-02 14:32:00', 20, 'aprovado', 1),
(2,'2025-05-03 16:15:00', 35, 'aprovado', 2),
(3,'2025-05-04 13:20:00', 50, 'pendente', 3),
(4,'2025-05-06 10:40:00', 20, 'aprovado', 4),
(5,'2025-05-07 18:10:00', 35, 'falhou', 5),
(6,'2025-05-08 19:55:00', 50, 'aprovado', 6),
(7,'2025-05-09 21:15:00', 20, 'aprovado', 7),
(8,'2025-05-10 17:05:00', 35, 'aprovado', 8),
(9,'2025-05-11 11:00:00', 50, 'aprovado', 9),
(10,'2025-05-12 12:30:00', 20, 'pendente', 10),
(11,'2025-05-13 15:25:00', 35, 'aprovado', 11),
(12,'2025-05-14 14:55:00', 50, 'falhou', 12),
(13,'2025-05-15 13:45:00', 20, 'aprovado', 13),
(14,'2025-05-16 16:35:00', 35, 'aprovado', 14),
(15,'2025-05-17 20:00:00', 50, 'aprovado', 15),
(16,'2025-05-18 22:10:00', 20, 'pendente', 16),
(17,'2025-05-19 08:15:00', 35, 'aprovado', 17),
(18,'2025-05-20 09:30:00', 50, 'falhou', 18),
(19,'2025-05-21 11:45:00', 20, 'aprovado', 19),
(20,'2025-05-22 13:20:00', 35, 'aprovado', 20),
(21,'2025-05-23 15:10:00', 50, 'aprovado', 21),
(22,'2025-05-24 17:00:00', 20, 'aprovado', 22),
(23,'2025-05-25 19:30:00', 35, 'falhou', 23),
(24,'2025-05-26 21:45:00', 50, 'aprovado', 24),
(25,'2025-05-27 20:30:00', 20, 'aprovado', 25);



